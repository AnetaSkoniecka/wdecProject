package WdecProject;

public class Ampl {
	
}
